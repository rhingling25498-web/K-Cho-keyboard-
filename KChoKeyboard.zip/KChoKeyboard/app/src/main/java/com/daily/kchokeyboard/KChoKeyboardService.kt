package com.daily.kchokeyboard

import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Vibrator
import android.os.VibrationEffect
import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.InsetDrawable
import android.content.res.ColorStateList
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.content.BroadcastReceiver
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.SeekBar
import android.widget.HorizontalScrollView
import android.widget.PopupWindow
import android.graphics.Bitmap
import android.widget.Toast
import android.app.AlertDialog
import android.widget.EditText
import android.speech.SpeechRecognizer
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.view.inputmethod.InputMethodManager

class KChoKeyboardService : InputMethodService() {

    private enum class Mode {
        KCHO, ENGLISH, MYANMAR, EMOJI, SYMBOLS
    }

    private lateinit var myanmarInputEngine: MyanmarInputEngine

    private var mode = Mode.KCHO
    private var previousMode = Mode.KCHO
    private var emojiPreviousMode = Mode.KCHO
    private var selectedEmojiCategory = "😀"
    private var shiftState = 0
    private var lastShiftTap = 0L

    private lateinit var root: LinearLayout

    private val qRow = listOf("q","w","e","r","t","y","u","i","o","p")
    private val aRow = listOf("a","s","d","f","g","h","j","k","l",";")
    private val zRow = listOf("z","x","c","v","b","n","m","y2")

    private val myNormal = mapOf(
        "1" to "ဈ", "2" to "ဝ", "3" to "ဋ",
        "4" to "ုံ", "5" to "ော", "6" to "ဪ",
        "7" to "ရ", "8" to "ဂ", "9" to "ဟ", "0" to "၏",

        "q" to "ဆ", "w" to "တ", "e" to "န",
        "r" to "မ", "t" to "အ", "y" to "ပ",
        "u" to "က", "i" to "င", "o" to "သ", "p" to "စ",

        "a" to "ေ", "s" to "ျ", "d" to "ိ",
        "f" to "်", "g" to "ါ", "h" to "့",
        "j" to "ြ", "k" to "ု", "l" to "ူ", ";" to "း",

        "z" to "ဖ", "x" to "ထ", "c" to "ခ",
        "v" to "လ", "b" to "ဘ", "n" to "ည",
        "m" to "ာ", "y2" to "ယ"
    )

    private val myShift = mapOf(
        "1" to "၁", "2" to "၂", "3" to "၃",
        "4" to "၄", "5" to "၅", "6" to "၆",
        "7" to "၇", "8" to "၈", "9" to "၉", "0" to "၀",

        "q" to "ဍ", "w" to "ဏ္ဍ", "e" to "ဣ",
        "r" to "၎င်း", "t" to "ဤ", "y" to "၌",
        "u" to "ဥ", "i" to "၍", "o" to "ဿ", "p" to "ဏ",

        "a" to "ဗ", "s" to "ှ", "d" to "ီ",
        "f" to "္", "g" to "ွ", "h" to "ံ",
        "j" to "ဲ", "k" to "ဒ", "l" to "ဓ", ";" to "ဏ္ဌ",

        "z" to "ဇ", "x" to "ဌ", "c" to "ဃ",
        "v" to "ဠ", "b" to "ဎ", "n" to "ဉ",
        "m" to "ဦ", "y2" to "ဧ"
    )

    private val themePrefsListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            val themeKeys = setOf(
                "background_image_uri",
                "background_opacity",
                "theme_applied",
                "keyboard_bg_opacity",
                "key_opacity",
                "font_size_value"
            )
            if (key != null && (key.startsWith("theme_") || key in themeKeys)) {
                if (key == "background_image_uri" || key == "theme_applied") {
                    cachedThemeUri = null
                    cachedThemeDrawable = null
                }
                Handler(Looper.getMainLooper()).post {
                    if (::root.isInitialized) refreshKeyboard()
                }
            }
        }

    // Voice status/result receiver. The toolbar stays inside the keyboard.
    private var voiceListening = false
    private var speechRecognizer: SpeechRecognizer? = null

    private val voiceResultReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                VoiceTypingActivity.ACTION_VOICE_STATE -> {
                    voiceListening = intent.getBooleanExtra(
                        VoiceTypingActivity.EXTRA_IS_LISTENING, false
                    )
                    Handler(Looper.getMainLooper()).post {
                        if (::root.isInitialized) {
                            if (voiceListening) showVoiceListeningToolbar()
                            else updateTopToolbarSuggestions()
                        }
                    }
                }

                VoiceTypingActivity.ACTION_VOICE_RESULT -> {
                    val recognizedText = intent
                        .getStringExtra(VoiceTypingActivity.EXTRA_RECOGNIZED_TEXT)
                        ?.trim()
                        .orEmpty()

                    if (recognizedText.isNotEmpty()) {
                        currentInputConnection?.commitText(recognizedText, 1)
                    }
                    voiceListening = false
                    Handler(Looper.getMainLooper()).post {
                        if (::root.isInitialized) updateTopToolbarSuggestions()
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()

        myanmarInputEngine = MyanmarInputEngine()
        personalDictionary = PersonalDictionary(this)
        keyboardPrefs.registerOnSharedPreferenceChangeListener(themePrefsListener)

        val voiceFilter = android.content.IntentFilter().apply {
            addAction(VoiceTypingActivity.ACTION_VOICE_RESULT)
            addAction(VoiceTypingActivity.ACTION_VOICE_STATE)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(
                voiceResultReceiver,
                voiceFilter,
                Context.RECEIVER_NOT_EXPORTED
            )
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(voiceResultReceiver, voiceFilter)
        }
    }

    override fun onDestroy() {
        stopVoiceTyping()
        keyboardPrefs.unregisterOnSharedPreferenceChangeListener(themePrefsListener)
        try {
            unregisterReceiver(voiceResultReceiver)
        } catch (_: IllegalArgumentException) {
            // Receiver was already unregistered.
        }
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        return buildKeyboard()
    }

    override fun onEvaluateFullscreenMode(): Boolean {
        return false
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    // THEME COLORS

    private fun getThemeColor(
        key: String,
        defaultColor: Int
    ): Int {
        return keyboardPrefs.getInt(key, defaultColor)
    }

    private fun hasBackgroundImage(): Boolean {
        return keyboardPrefs.getBoolean("theme_applied", false) &&
                keyboardPrefs.getString("background_image_uri", null) != null
    }

    // SHIFT ICON

    private inner class ShiftIconDrawable(
        private val state: Int,
        iconColor: Int = getThemeColor(
            "theme_special_icon_color",
            Color.WHITE
        )
    ) : Drawable() {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = iconColor
            strokeWidth = dp(2).toFloat()
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()

            canvas.save()
            canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())

            val path = Path().apply {
                moveTo(w * 0.5f, h * 0.20f)
                lineTo(w * 0.31f, h * 0.40f)
                quadTo(w * 0.27f, h * 0.45f, w * 0.34f, h * 0.45f)
                lineTo(w * 0.40f, h * 0.45f)
                lineTo(w * 0.40f, h * 0.78f)
                quadTo(w * 0.40f, h * 0.83f, w * 0.45f, h * 0.83f)
                lineTo(w * 0.55f, h * 0.83f)
                quadTo(w * 0.60f, h * 0.83f, w * 0.60f, h * 0.78f)
                lineTo(w * 0.60f, h * 0.45f)
                lineTo(w * 0.66f, h * 0.45f)
                quadTo(w * 0.73f, h * 0.45f, w * 0.69f, h * 0.40f)
                close()
            }

            when (state) {
                0 -> {
                    paint.style = Paint.Style.STROKE
                    canvas.drawPath(path, paint)
                }

                1, 2 -> {
                    paint.style = Paint.Style.FILL
                    canvas.drawPath(path, paint)
                }
            }

            if (state == 2) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = dp(2).toFloat()
                canvas.drawLine(
                    w * 0.32f, h * 0.94f,
                    w * 0.68f, h * 0.94f,
                    paint
                )
            }

            canvas.restore()
        }

        override fun setAlpha(alpha: Int) {
            paint.alpha = alpha
        }

        override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
            paint.colorFilter = colorFilter
        }

        override fun getOpacity(): Int {
            return PixelFormat.TRANSLUCENT
        }
    }

    // BACKSPACE ICON

    private inner class BackspaceIconDrawable(
        iconColor: Int = getThemeColor(
            "theme_special_icon_color",
            Color.WHITE
        )
    ) : Drawable() {

        private val iconColor = iconColor

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = iconColor
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            style = Paint.Style.FILL
        }

        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()

            val saveCount = canvas.save()

            canvas.translate(
                bounds.left.toFloat(),
                bounds.top.toFloat()
            )

            val path = Path().apply {
                moveTo(w * 0.30f, h * 0.18f)
                lineTo(w * 0.88f, h * 0.18f)
                quadTo(w * 0.96f, h * 0.18f, w * 0.96f, h * 0.26f)
                lineTo(w * 0.96f, h * 0.74f)
                quadTo(w * 0.96f, h * 0.82f, w * 0.88f, h * 0.82f)
                lineTo(w * 0.30f, h * 0.82f)
                lineTo(w * 0.04f, h * 0.50f)
                close()
            }

            paint.color = iconColor
            paint.style = Paint.Style.FILL
            canvas.drawPath(path, paint)

            paint.color = Color.WHITE
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(2).toFloat()

            canvas.drawLine(
                w * 0.46f, h * 0.36f,
                w * 0.72f, h * 0.64f,
                paint
            )

            canvas.drawLine(
                w * 0.72f, h * 0.36f,
                w * 0.46f, h * 0.64f,
                paint
            )

            canvas.restoreToCount(saveCount)
        }

        override fun setAlpha(alpha: Int) {
            paint.alpha = alpha
        }

        override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
            paint.colorFilter = colorFilter
        }

        override fun getOpacity(): Int {
            return PixelFormat.TRANSLUCENT
        }
    }

    // KEYBOARD BACKGROUND: COLOR + OPTIONAL IMAGE

    private fun applyKeyboardBackground() {
        val backgroundColor = getThemeColor(
            "theme_keyboard_bg_color",
            Color.rgb(220, 235, 250)
        )
        val keyboardOpacity = keyboardPrefs.getInt(
            "keyboard_bg_opacity", 100
        ).coerceIn(0, 100)
        val isApplied = keyboardPrefs.getBoolean("theme_applied", false)
        val imageUri = keyboardPrefs.getString("background_image_uri", null)
        val imageOpacity = keyboardPrefs.getInt("background_opacity", 100)
            .coerceIn(0, 100)

        fun setColorOnly() {
            root.background = ColorDrawable(backgroundColor).apply {
                alpha = keyboardOpacity * 255 / 100
            }
        }

        if (!isApplied || imageUri.isNullOrEmpty()) {
            setColorOnly()
            return
        }

        fun installLayers(image: Drawable) {
            image.alpha = imageOpacity * 255 / 100
            val colorOverlay = ColorDrawable(backgroundColor).apply {
                alpha = keyboardOpacity * 255 / 100
            }
            // LayerDrawable draws index 0 first (bottom), then index 1 (top).
            root.background = LayerDrawable(arrayOf(image, colorOverlay))
        }

        if (cachedThemeUri == imageUri && cachedThemeDrawable != null) {
            val imageDrawable = cachedThemeDrawable!!.constantState
                ?.newDrawable(resources)?.mutate() as? Drawable
                ?: cachedThemeDrawable!!.mutate()
            installLayers(imageDrawable)
            return
        }

        try {
            val uri = android.net.Uri.parse(imageUri)
            val targetWidth = resources.displayMetrics.widthPixels
            val targetHeight = dp(285)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                setColorOnly()
                return
            }

            val scale = maxOf(
                targetWidth.toFloat() / bounds.outWidth,
                targetHeight.toFloat() / bounds.outHeight
            )
            val requiredWidth = (targetWidth / scale).toInt()
            val requiredHeight = (targetHeight / scale).toInt()
            var sampleSize = 1
            while (
                bounds.outWidth / (sampleSize * 2) >= requiredWidth &&
                bounds.outHeight / (sampleSize * 2) >= requiredHeight
            ) sampleSize *= 2

            val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val sourceBitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }
            if (sourceBitmap == null) {
                setColorOnly()
                return
            }

            val resultBitmap = Bitmap.createBitmap(
                targetWidth, targetHeight, Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(resultBitmap)
            val cropScale = maxOf(
                targetWidth.toFloat() / sourceBitmap.width,
                targetHeight.toFloat() / sourceBitmap.height
            )
            val drawWidth = sourceBitmap.width * cropScale
            val drawHeight = sourceBitmap.height * cropScale
            val left = (targetWidth - drawWidth) / 2f
            val top = (targetHeight - drawHeight) / 2f
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(
                sourceBitmap, null,
                android.graphics.RectF(left, top, left + drawWidth, top + drawHeight),
                paint
            )
            sourceBitmap.recycle()

            val newBackground = BitmapDrawable(resources, resultBitmap).apply {
                gravity = Gravity.FILL
            }
            cachedThemeUri = imageUri
            cachedThemeDrawable = newBackground
            val imageLayer = newBackground.constantState
                ?.newDrawable(resources)?.mutate() as? Drawable ?: newBackground
            installLayers(imageLayer)
        } catch (e: Exception) {
            e.printStackTrace()
            setColorOnly()
        }
    }

    private var cachedThemeUri: String? = null
    private var cachedThemeDrawable: BitmapDrawable? = null
    private var topToolbar: LinearLayout? = null
    private var keyboardToolsPopup: PopupWindow? = null
    private var popupDismissedAt = 0L

    // BUILD KEYBOARD

    private fun buildKeyboard(): View {

        root = object : LinearLayout(this) {

            override fun onMeasure(
                widthMeasureSpec: Int,
                heightMeasureSpec: Int
            ) {
                if (mode == Mode.EMOJI) {
                    val fixedHeight = MeasureSpec.makeMeasureSpec(
                        dp(285),
                        MeasureSpec.EXACTLY
                    )

                    super.onMeasure(widthMeasureSpec, fixedHeight)
                } else {
                    super.onMeasure(widthMeasureSpec, heightMeasureSpec)
                }
            }

        }.apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(3), dp(3), dp(3), dp(3))

            setBackgroundColor(
                getThemeColor(
                    "theme_keyboard_bg_color",
                    Color.rgb(220, 235, 250)
                )
            )

            clipChildren = true
            clipToPadding = true

            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(285)
            )

            minimumHeight = dp(285)
        }

        applyKeyboardBackground()

        if (
            mode == Mode.KCHO ||
            mode == Mode.ENGLISH ||
            mode == Mode.MYANMAR
        ) {
            showTopToolbar()
        }

        when (mode) {
            Mode.EMOJI -> showEmojiPanel()
            Mode.SYMBOLS -> showSymbolPanel()
            else -> showLetterPanel()
        }

        return root
    }

    private lateinit var personalDictionary: PersonalDictionary

    // TOP TOOLBAR

    private fun showTopToolbar() {

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), 0, dp(3), 0)

            setBackgroundColor(
                getThemeColor(
                    "theme_toolbar_bg_color",
                    Color.rgb(220, 235, 250)
                )
            )
        }

        topToolbar = toolbar

        root.addView(
            toolbar,
            0,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(40)
            )
        )

        updateTopToolbarSuggestions()
    }

    private fun startVoiceTyping() {
        if (voiceListening) {
            stopVoiceTyping()
            updateTopToolbarSuggestions()
            return
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(
                this,
                "Microphone permission ကို App ထဲမှာ အရင်ခွင့်ပြုပေးပါ။",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(
                this,
                "ဒီဖုန်းမှာ Speech Recognition မရနိုင်ပါ။ Google app ကို Update လုပ်ပါ။",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        voiceListening = true
                        if (::root.isInitialized) showVoiceListeningToolbar()
                    }

                    override fun onBeginningOfSpeech() {
                        voiceListening = true
                        if (::root.isInitialized) showVoiceListeningToolbar()
                    }

                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit

                    override fun onEndOfSpeech() {
                        voiceListening = false
                        if (::root.isInitialized) updateTopToolbarSuggestions()
                    }

                    override fun onError(error: Int) {
                        voiceListening = false
                        if (::root.isInitialized) updateTopToolbarSuggestions()
                        val message = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH,
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                "အသံမကြားရပါ။ Microphone ကို ထပ်နှိပ်ပြီး ပြောပါ။"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                "Microphone permission မရရှိပါ။"
                            else ->
                                "အသံမှတ်တမ်း မအောင်မြင်ပါ။ Internet နဲ့ Google Speech service ကို စစ်ပါ။"
                        }
                        Toast.makeText(this@KChoKeyboardService, message, Toast.LENGTH_LONG).show()
                        speechRecognizer?.destroy()
                        speechRecognizer = null
                    }

                    override fun onResults(results: Bundle?) {
                        voiceListening = false
                        val recognizedText = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()

                        if (recognizedText.isNotEmpty()) {
                            currentInputConnection?.commitText(recognizedText, 1)
                        }

                        if (::root.isInitialized) updateTopToolbarSuggestions()
                        speechRecognizer?.destroy()
                        speechRecognizer = null
                    }

                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })

                val languageTag = when (mode) {
                    Mode.ENGLISH -> "en-US"
                    Mode.MYANMAR, Mode.KCHO -> "my-MM"
                    else -> "my-MM"
                }

                val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                }

                startListening(recognizerIntent)
            }
        } catch (e: Exception) {
            voiceListening = false
            speechRecognizer?.destroy()
            speechRecognizer = null
            Toast.makeText(
                this,
                "အသံမှတ်တမ်း စတင်မရပါ။ Speech service ကို စစ်ဆေးပါ။",
                Toast.LENGTH_LONG
            ).show()
            if (::root.isInitialized) updateTopToolbarSuggestions()
        }
    }

    private fun showVoiceListeningToolbar() {
        val toolbar = topToolbar ?: return
        toolbar.removeAllViews()

        val iconColor = getThemeColor(
            "theme_toolbar_icon_color",
            Color.rgb(39, 101, 220)
        )

        val status = TextView(this).apply {
            text = "🎙  နားထောင်နေသည်..."
            textSize = 16f
            gravity = Gravity.CENTER
            maxLines = 1
            setTextColor(iconColor)
            layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f)
        }

        val stop = TextView(this).apply {
            text = "✕"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(iconColor)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(40))
            setOnClickListener {
                stopVoiceTyping()
                updateTopToolbarSuggestions()
            }
        }

        toolbar.addView(status)
        toolbar.addView(stop)
    }


    private fun showKeyboardActionPopup(
        title: String,
        items: List<String>,
        onItemClick: (Int) -> Unit
    ) {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.WHITE)
        }

        val heading = TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(Color.rgb(39, 101, 220))
            setPadding(dp(12), dp(10), dp(12), dp(12))
        }

        content.addView(heading)

        val popup = PopupWindow(
            content,
            dp(240),
            LinearLayout.LayoutParams.WRAP_CONTENT,
            false
        )

        items.forEachIndexed { index, item ->
            val button = TextView(this).apply {
                text = item
                textSize = 15f
                setTextColor(Color.DKGRAY)
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))

                setOnClickListener {
                    popup.dismiss()
                    onItemClick(index)
                }
            }

            content.addView(
                button,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }

        popup.apply {
            isFocusable = false
            isTouchable = true
            isOutsideTouchable = true
            setBackgroundDrawable(
                android.graphics.drawable.ColorDrawable(Color.WHITE)
            )
        }

        val anchor = topToolbar ?: return
        popup.showAsDropDown(anchor, 0, 0)
    }




    private fun showKeyboardToolsMenu() {

        if (keyboardToolsPopup?.isShowing == true) {
            return
        }

        val menuItems = listOf(
            "⌨  Keyboard Switcher",
            "📋  Clipboard",
            "✂  Text Editing"
        )

        val popupContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
        }

        val popup = PopupWindow(
            popupContent,
            dp(220),
            LinearLayout.LayoutParams.WRAP_CONTENT,
            false
        ).apply {

            isFocusable = false
            isTouchable = true
            isOutsideTouchable = true

            setBackgroundDrawable(
                android.graphics.drawable.ColorDrawable(Color.WHITE)
            )

            setOnDismissListener {
                popupDismissedAt =
                    android.os.SystemClock.uptimeMillis()

                keyboardToolsPopup = null
            }
        }

        menuItems.forEachIndexed { index, title ->

            val itemView = TextView(this).apply {
                text = title
                textSize = 16f
                setTextColor(Color.rgb(39, 101, 220))
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))

                background =
                    android.graphics.drawable.GradientDrawable().apply {
                        setColor(Color.WHITE)
                        cornerRadius = dp(8).toFloat()
                    }
            }

            itemView.setOnClickListener {

                popup.dismiss()

                when (index) {
                    0 -> {
                        val imm = getSystemService(
                            INPUT_METHOD_SERVICE
                        ) as InputMethodManager

                        imm.showInputMethodPicker()
                    }

                    1 -> showClipboardHistory()

                    2 -> showTextEditingTools()
                }
            }

            popupContent.addView(itemView)
        }

        val anchor = topToolbar ?: return

        keyboardToolsPopup = popup
        popup.showAsDropDown(anchor, 0, 0)
    }






    private fun showClipboardHistory() {

        val clipboardManager = getSystemService(
            CLIPBOARD_SERVICE
        ) as android.content.ClipboardManager

        if (!clipboardManager.hasPrimaryClip()) {
            Toast.makeText(
                this,
                "Clipboard is empty",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val clip = clipboardManager.primaryClip
        val items = mutableListOf<String>()

        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                val text = clip.getItemAt(i)
                    .coerceToText(this)
                    .toString()

                if (text.isNotBlank()) {
                    items.add(text)
                }
            }
        }

        if (items.isEmpty()) {
            Toast.makeText(
                this,
                "No text in Clipboard",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        showKeyboardActionPopup(
            "📋 Clipboard",
            items
        ) { which ->
            currentInputConnection?.commitText(
                items[which],
                1
            )
        }
    }


    private fun showTextEditingTools() {

        val options = listOf(
            "⬅  Move Cursor Left",
            "➡  Move Cursor Right",
            "📋  Select All",
            "📄  Copy",
            "✂  Cut",
            "📥  Paste"
        )

        showKeyboardActionPopup(
            "Text Editing",
            options
        ) { which ->

            val connection = currentInputConnection
                ?: return@showKeyboardActionPopup

            when (which) {
                0 -> connection.sendKeyEvent(
                    android.view.KeyEvent(
                        android.view.KeyEvent.ACTION_DOWN,
                        android.view.KeyEvent.KEYCODE_DPAD_LEFT
                    )
                )

                1 -> connection.sendKeyEvent(
                    android.view.KeyEvent(
                        android.view.KeyEvent.ACTION_DOWN,
                        android.view.KeyEvent.KEYCODE_DPAD_RIGHT
                    )
                )

                2 -> connection.performContextMenuAction(
                    android.R.id.selectAll
                )

                3 -> connection.performContextMenuAction(
                    android.R.id.copy
                )

                4 -> connection.performContextMenuAction(
                    android.R.id.cut
                )

                5 -> connection.performContextMenuAction(
                    android.R.id.paste
                )
            }
        }
    }




    private fun showOriginalToolbarIcons() {

        val toolbar = topToolbar ?: return
        toolbar.removeAllViews()

        val toolbarIconColor = getThemeColor(
            "theme_toolbar_icon_color",
            Color.rgb(39, 101, 220)
        )

        val items = listOf(
            "☰", "😊", "GIF", "⚙", "文A", "🎨", "🎙"
        )

        for (item in items) {

            val button = TextView(this).apply {
                text = item
                textSize = if (item == "GIF") 15f else 21f
                gravity = Gravity.CENTER
                setTextColor(toolbarIconColor)
                setBackgroundColor(Color.TRANSPARENT)

                layoutParams = LinearLayout.LayoutParams(
                    0,
                    dp(40),
                    1f
                )
            }

            button.setOnClickListener {
                when (item) {

                    "☰" -> {
                        val now = android.os.SystemClock.uptimeMillis()

                        // Popup ပိတ်ပြီးချင်း ပြန်ဖွင့်မိခြင်းကို ကာကွယ်မယ်
                        if (now - popupDismissedAt < 250L) {
                            return@setOnClickListener
                        }

                        val popup = keyboardToolsPopup

                        if (popup?.isShowing == true) {
                            popup.dismiss()
                        } else {
                            showKeyboardToolsMenu()
                        }
                    }

                    "😊" -> handleKey("EMOJI")

                    "⚙" -> {
                        try {
                            val intent = Intent(
                                this,
                                SettingsActivity::class.java
                            ).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    "🎨" -> {
                        try {
                            val intent = Intent(
                                this,
                                SettingsActivity::class.java
                            ).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                putExtra("open_theme", true)
                            }
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    "文A" -> {
                        Toast.makeText(
                            this,
                            "Coming soon",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    "🎙" -> startVoiceTyping()

                    else -> {
                        // Other toolbar tools
                    }
                }
            }

            toolbar.addView(button)
        }
    }




    private fun updateTopToolbarSuggestions() {

        val toolbar = topToolbar ?: return

        if (voiceListening) {
            showVoiceListeningToolbar()
            return
        }

        // Toolbar color ကို အမြဲသတ်မှတ်ထားမည်
        toolbar.setBackgroundColor(
            getThemeColor(
                "theme_toolbar_bg_color",
                Color.rgb(220, 235, 250)
            )
        )

        if (!keyboardPrefs.getBoolean("auto_suggestions", true)) {
            showOriginalToolbarIcons()
            return
        }

        val language = when (mode) {
            Mode.KCHO -> PersonalDictionary.KCHO
            Mode.ENGLISH -> PersonalDictionary.ENGLISH
            Mode.MYANMAR -> PersonalDictionary.MYANMAR
            else -> {
                showOriginalToolbarIcons()
                return
            }
        }

        val ic = currentInputConnection

        val before = ic?.getTextBeforeCursor(100, 0)
            ?.toString() ?: ""

        val prefix = before.substringAfterLast(" ")

        if (prefix.isEmpty()) {
            showOriginalToolbarIcons()
            return
        }

        toolbar.removeAllViews()

        val toolbarIconColor = getThemeColor(
            "theme_toolbar_icon_color",
            Color.rgb(39, 101, 220)
        )

        val suggestions = personalDictionary.getSuggestions(
            prefix,
            language,
            3
        )

        for (word in suggestions) {

            val button = TextView(this).apply {
                text = word
                textSize = 17f
                gravity = Gravity.CENTER
                maxLines = 1
                setTextColor(toolbarIconColor)
                setBackgroundColor(Color.TRANSPARENT)

                layoutParams = LinearLayout.LayoutParams(
                    0,
                    dp(40),
                    1f
                )
            }

            button.setOnClickListener {

                val connection =
                    currentInputConnection ?: return@setOnClickListener

                val currentText = connection
                    .getTextBeforeCursor(100, 0)
                    ?.toString() ?: ""

                val currentPrefix = currentText.substringAfterLast(" ")

                if (currentPrefix.isNotEmpty()) {

                    connection.deleteSurroundingText(
                        currentPrefix.length,
                        0
                    )

                    connection.commitText("$word ", 1)
                }

                updateTopToolbarSuggestions()
            }

            toolbar.addView(button)
        }
    }


    // =====================================
    // K'CHO KEYBOARD SETTINGS
    // =====================================
    private fun stopVoiceTyping() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
        voiceListening = false
    }

    private fun showSettingsMenu() {

        val settingsItems = arrayOf(
            "Preference",
            "Theme",
            "Correction & Suggestions",
            "About"
        )

        AlertDialog.Builder(this)
            .setTitle("K'Cho Keyboard Settings")
            .setItems(settingsItems) { _, which ->
                when (which) {
                    0 -> showPreferenceSettings()
                    1 -> showThemeSettings()
                    2 -> showCorrectionSettings()
                    3 -> showAbout()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }


    // =====================================
    // PREFERENCE SETTINGS
    // =====================================

    private fun showPreferenceSettings() {

        val preferences = getSharedPreferences(
            "kcho_keyboard_settings",
            Context.MODE_PRIVATE
        )

        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(12), dp(22), dp(4))
        }

        val valueLabel = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.rgb(39, 101, 220))
            gravity = Gravity.CENTER
        }

        val seekBar = SeekBar(this).apply {
            max = 10
            progress = (preferences.getInt("font_size_value", 20) - 12)
                .coerceIn(0, 10)
        }

        fun updateFontLabel(value: Int) {
            valueLabel.text = "Font Size: $value"
        }

        updateFontLabel(seekBar.progress + 12)
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar?,
                progress: Int,
                fromUser: Boolean
            ) {
                val value = progress + 12
                updateFontLabel(value)
                preferences.edit().putInt("font_size_value", value).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        wrapper.addView(valueLabel)
        wrapper.addView(seekBar)

        AlertDialog.Builder(this)
            .setTitle("Preference")
            .setView(wrapper)
            .setPositiveButton("Sound / Vibration") { _, _ ->
                showSoundVibrationSettings()
            }
            .setNegativeButton("Close", null)
            .show()
    }


    private fun showSoundVibrationSettings() {

        val preferences = getSharedPreferences(
            "kcho_keyboard_settings",
            Context.MODE_PRIVATE
        )

        val soundEnabled = preferences.getBoolean(
            "sound_enabled",
            true
        )

        val vibrationEnabled = preferences.getBoolean(
            "vibration_enabled",
            true
        )

        val options = arrayOf(
            "Sound",
            "Vibration"
        )

        val checked = booleanArrayOf(
            soundEnabled,
            vibrationEnabled
        )

        AlertDialog.Builder(this)
            .setTitle("Sound & Vibration")
            .setMultiChoiceItems(
                options,
                checked
            ) { _, which, isChecked ->

                if (which == 0) {
                    preferences.edit()
                        .putBoolean("sound_enabled", isChecked)
                        .apply()
                }

                if (which == 1) {
                    preferences.edit()
                        .putBoolean("vibration_enabled", isChecked)
                        .apply()
                }
            }
            .setPositiveButton("OK", null)
            .show()
    }


    // =====================================
    // THEME SETTINGS
    // =====================================

    private fun showThemeSettings() {

        try {
            val intent = Intent(
                this,
                SettingsActivity::class.java
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("open_theme", true)
            }

            startActivity(intent)

        } catch (e: Exception) {
            e.printStackTrace()

            Toast.makeText(
                this,
                "Unable to open Theme Settings",
                Toast.LENGTH_SHORT
            ).show()
        }
    }


    private fun showMyTheme() {
        showThemeSettings()
    }


    private fun showBackgroundImageInfo() {
        showThemeSettings()
    }


    private fun showOpacitySettings() {
        showThemeSettings()
    }


    // =====================================
    // CORRECTION & SUGGESTIONS
    // =====================================

    private fun showCorrectionSettings() {

        val preferences = getSharedPreferences(
            "kcho_keyboard_settings",
            Context.MODE_PRIVATE
        )

        val options = arrayOf(
            "Auto Word Suggestions"
        )

        val checked = booleanArrayOf(
            preferences.getBoolean("auto_suggestions", true)
        )

        AlertDialog.Builder(this)
            .setTitle("Correction & Suggestions")
            .setMultiChoiceItems(
                options,
                checked
            ) { _, which, isChecked ->

                if (which == 0) {
                    preferences.edit()
                        .putBoolean(
                            "auto_suggestions",
                            isChecked
                        )
                        .apply()
                }
            }
            .setPositiveButton("OK", null)
            .setNegativeButton("Close", null)
            .show()
    }


    // =====================================
    // ABOUT
    // =====================================

    private fun showAbout() {

        AlertDialog.Builder(this)
            .setTitle("About K'Cho Keyboard")
            .setMessage(
                "K'Cho k'chang gui \"K'Choca\" ami guk then nak a ng'hlawi pi vai ah hmawk ah büne shin ah \"K'Cho Keyboard\" cu Ng'Lo Rhing Ling naw 2026 kum ung a pyan ah Kya ci.\n\n" +

                        "Software Name: K'Cho Keyboard\n" +
                        "Software Version: 1.0.0\n" +
                        "Copyright: Ng'Lo Rhing Ling"
            )
            .setPositiveButton("OK", null)
            .show()
    }


    private fun withOpacity(color: Int, opacity: Int): Int {
        val alpha = Color.alpha(color) * opacity.coerceIn(0, 100) / 100
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    }

    // =====================================
    // ADD KEY ROW - THEME ENABLED
    // =====================================

    private fun addRow(keys: List<String>) {

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        // Theme colors
        val keyTextColor = getThemeColor(
            "theme_key_text_color",
            Color.rgb(39, 101, 220)
        )

        val keyBackgroundColor = getThemeColor(
            "theme_key_bg_color",
            Color.WHITE
        )

        val specialBackgroundColor = getThemeColor(
            "theme_special_key_bg_color",
            Color.rgb(39, 101, 220)
        )

        val specialIconColor = getThemeColor(
            "theme_special_icon_color",
            Color.WHITE
        )

        val borderColor = getThemeColor(
            "theme_key_border_color",
            Color.LTGRAY
        )

        val shadowColor = getThemeColor(
            "theme_key_shadow_color",
            Color.GRAY
        )

        val keyOpacity = keyboardPrefs.getInt("key_opacity", 100)
            .coerceIn(0, 100)

        for (key in keys) {

            val isSpecialKey = key in listOf(
                "SHIFT",
                "BACK",
                "ENTER"
            )

            val button = Button(this)

            button.text = when (key) {

                "SHIFT", "BACK" -> ""

                "SPACE" -> when (mode) {
                    Mode.KCHO -> "K'Cho"
                    Mode.ENGLISH -> "English"
                    Mode.MYANMAR -> "Myanmar"
                    else -> " "
                }

                else -> getLabel(key)
            }

            button.isAllCaps = false
            button.includeFontPadding = true
            button.setSingleLine(true)
            val shiftSize = keyboardPrefs.getInt("theme_shift_size", 100) / 100f
            val symbolSize = keyboardPrefs.getInt("theme_symbol_size", 100) / 100f
            val enterSize = keyboardPrefs.getInt("theme_enter_size", 100) / 100f


            button.textSize = when {

                key == "SYMBOL" -> 13f * symbolSize

                key == "ENTER" -> 20f * enterSize

                key == "SYMBOL" -> 13f

                key == "SPACE" -> 17f

                key == "SHIFT" || key == "BACK" -> 25f

                mode == Mode.MYANMAR &&
                        getLabel(key) == "ဪ" -> 14f

                mode == Mode.MYANMAR &&
                        getLabel(key) in listOf(
                    "ဍ", "ဏ္ဍ", "ဣ", "၎င်း",
                    "ဤ", "ဿ", "ဏ္ဌ", "ဉ"
                ) -> 17f

                mode == Mode.KCHO &&
                        key in listOf("Hng", "Phl", "Phy") -> 18f

                mode == Mode.KCHO &&
                        key in listOf(
                            "k'", "m'", "ng'", "py",
                            "K'", "M'", "Ng'"
                        ) -> 22f

                mode == Mode.MYANMAR ->
                    keyboardPrefs.getInt("font_size_value", 20)
                        .coerceIn(12, 22).toFloat()

                mode == Mode.KCHO || mode == Mode.ENGLISH ->
                    keyboardPrefs.getInt("font_size_value", 20)
                        .coerceIn(12, 22).toFloat()

                else -> 19f
            }

            button.typeface = Typeface.create(
                "sans-serif-light",
                Typeface.NORMAL
            )

            // Normal / Special key text color
            button.setTextColor(
                if (isSpecialKey) {
                    specialIconColor
                } else {
                    keyTextColor
                }
            )

            // Key background
            val selectedBackgroundColor = if (isSpecialKey) {
                specialBackgroundColor
            } else {
                keyBackgroundColor
            }

            val keyBackground = GradientDrawable().apply {

                setColor(withOpacity(selectedBackgroundColor, keyOpacity))

                cornerRadius = dp(15).toFloat()

                setStroke(
                    dp(1),
                    withOpacity(borderColor, keyOpacity)
                )
            }

            // Key icon backgrounds
            button.background = when (key) {

                "SHIFT" -> {
                    LayerDrawable(
                        arrayOf(
                            keyBackground,
                            InsetDrawable(
                                ShiftIconDrawable(
                                    shiftState,
                                    specialIconColor
                                ),
                                dp((10f / shiftSize).toInt()),
                                dp((12f / shiftSize).toInt()),
                                dp((10f / shiftSize).toInt()),
                                dp((12f / shiftSize).toInt())
                            )
                        )
                    )
                }

                "BACK" -> {
                    LayerDrawable(
                        arrayOf(
                            keyBackground,
                            InsetDrawable(
                                BackspaceIconDrawable(
                                    specialIconColor
                                ),
                                dp(5),
                                dp(10),
                                dp(5),
                                dp(10)
                            )
                        )
                    )
                }

                else -> keyBackground
            }

            button.backgroundTintList = null

            // Align Myanmar special keys individually without moving their key slots.
            // Normal state: lift only "ဪ" (key 6).
            if (mode == Mode.MYANMAR && shiftState == 0 && key == "6") {
                button.translationY = -dp(3).toFloat()
            }

            // Shift state: lift only "ဉ" (the shifted label on key n).
            if (mode == Mode.MYANMAR && shiftState > 0 && key == "n") {
                button.translationY = -dp(3).toFloat()
            }

            button.elevation = dp(3).toFloat()

            // Shadow color support
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                button.outlineAmbientShadowColor = shadowColor
                button.outlineSpotShadowColor = shadowColor
            }

            button.minWidth = 0
            button.minHeight = 0

            button.setPadding(
                dp(1),
                0,
                dp(1),
                0
            )

            // Keep original key widths
            val weight = when (key) {

                "SPACE" -> 3.5f

                "COMMA", "PERIOD" -> 1f

                "SHIFT", "BACK" -> 1.1f

                else -> 1.4f
            }

            val params = LinearLayout.LayoutParams(
                0,
                dp(58),
                weight
            )

            params.setMargins(
                dp(1),
                dp(2),
                dp(1),
                dp(2)
            )

            row.addView(button, params)

            // BACKSPACE LONG PRESS
            if (key == "BACK") {

                val backHandler = Handler(
                    Looper.getMainLooper()
                )

                val repeatBack = object : Runnable {

                    override fun run() {
                        handleKey("BACK")
                        backHandler.postDelayed(this, 55)
                    }
                }

                button.setOnTouchListener { _, event ->

                    when (event.action) {

                        MotionEvent.ACTION_DOWN -> {

                            performKeyFeedback()

                            handleKey("BACK")

                            backHandler.postDelayed(
                                repeatBack,
                                350
                            )

                            true
                        }

                        MotionEvent.ACTION_UP,
                        MotionEvent.ACTION_CANCEL -> {

                            backHandler.removeCallbacks(
                                repeatBack
                            )

                            true
                        }

                        else -> true
                    }
                }

            } else {

                button.setOnClickListener {

                    performKeyFeedback()

                    handleKey(key)
                }
            }



        }

        root.addView(row)
    }


    // =====================================
    // SHARED PREFERENCES
    // =====================================

    private val keyboardPrefs by lazy {
        getSharedPreferences(
            "kcho_keyboard_settings",
            Context.MODE_PRIVATE
        )
    }


    // =====================================
    // SOUND / VIBRATION
    // =====================================

    private var keyTone: ToneGenerator? = null

    private fun performKeyFeedback() {

        // SOUND
        if (keyboardPrefs.getBoolean("sound_enabled", true)) {

            try {

                if (keyTone == null) {
                    keyTone = ToneGenerator(
                        AudioManager.STREAM_SYSTEM,
                        35
                    )
                }

                keyTone?.startTone(
                    ToneGenerator.TONE_PROP_BEEP,
                    35
                )

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // VIBRATION
        if (keyboardPrefs.getBoolean("vibration_enabled", true)) {

            try {

                val vibrator = getSystemService(
                    Context.VIBRATOR_SERVICE
                ) as Vibrator

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                    vibrator.vibrate(
                        VibrationEffect.createOneShot(
                            18,
                            VibrationEffect.DEFAULT_AMPLITUDE
                        )
                    )

                } else {

                    @Suppress("DEPRECATION")
                    vibrator.vibrate(18)
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
        // KEY LABEL

        private fun getLabel(key: String): String {

            if (key == "SHIFT") return "⬆"
            if (key == "BACK") return "⌫"
            if (key == "ENTER") return "↵"
            if (key == "SPACE") return "space"
            if (key == "GLOBE") return "🌐"
            if (key == "EMOJI") return "😊"
            if (key == "SYMBOL") return "123?"

            if (key == "COMMA") {
                return if (mode == Mode.MYANMAR) "၊" else ","
            }

            if (key == "PERIOD") {
                return if (mode == Mode.MYANMAR) "။" else "."
            }

            if (mode == Mode.MYANMAR) {
                val map = if (shiftState > 0) myShift else myNormal
                return map[key] ?: key
            }

            if (mode == Mode.KCHO) {

                // K'Cho special keys: မူရင်းစာလုံးအတိုင်း ပြရန်
                if (key in listOf(
                        "k'", "m'", "ng'", "py",
                        "K'", "M'", "Ng'", "Hng", "Phl", "Phy"
                    )
                ) return key

                if (key == "q") return if (shiftState > 0) "Ä" else "ä"
                if (key == "z") return if (shiftState > 0) "Ü" else "ü"
                if (key == "ë") return if (shiftState > 0) "Ë" else "ë"
            }

            return if (shiftState > 0) key.uppercase()
            else key.lowercase()
        }


        // LETTER KEYBOARD

        private fun showLetterPanel() {

            val numberRow = if (mode == Mode.KCHO && shiftState == 0) {
                listOf("k'", "m'", "ng'", "py", "K'", "M'", "Ng'", "Hng", "Phl", "Phy")
            } else {
                listOf("1","2","3","4","5","6","7","8","9","0")
            }

        addRow(numberRow)
        addRow(qRow)
        addRow(aRow)

        val bottomLetters = when (mode) {
            Mode.MYANMAR -> zRow

            Mode.KCHO -> listOf("z", "ë", "c", "v", "b", "n", "m")

            else -> listOf("z", "x", "c", "v", "b", "n", "m")
        }

        addRow(listOf("SHIFT") + bottomLetters + listOf("BACK"))

        addRow(
            listOf(
                "SYMBOL", "COMMA", "GLOBE",
                "SPACE", "EMOJI", "PERIOD", "ENTER"
            )
        )
    }

    // EMOJI PANEL
    private fun showEmojiPanel() {

        val categories = linkedMapOf(
            "😀" to listOf(
                "😀","😃","😄","😁","😆","😅","🤣","😂",
                "🙂","🙃","😉","😊","😇","🥰","😍","🤩",
                "😘","😗","☺️","😚","😙","🥲","😋","😛",
                "😜","🤪","😝","🤑","🤗","🤭","🤫","🤔",
                "🤐","🤨","😐","😑","😶","😏","😒","🙄",
                "😬","🤥","😌","😔","😪","🤤","😴","😷"
            ),

            "👋" to listOf(
                "👋","🤚","🖐️","✋","🖖","👌","🤌","🤏",
                "✌️","🤞","🫰","🤟","🤘","🤙","👈","👉",
                "👆","🖕","👇","☝️","👍","👎","✊","👊",
                "🤛","🤜","👏","🙌","👐","🤲","🤝","🙏"
            ),

            "👨" to listOf(
                "👶","🧒","👦","👧","🧑","👨","👩","🧔",
                "👴","👵","👮","👷","💂","🕵️","👩‍⚕️","👨‍⚕️",
                "👩‍🎓","👨‍🎓","👩‍🏫","👨‍🏫","👩‍💻","👨‍💻",
                "👩‍🍳","👨‍🍳","👩‍🚀","👨‍🚀"
            ),

            "🐶" to listOf(
                "🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼",
                "🐻‍❄️","🐨","🐯","🦁","🐮","🐷","🐸","🐵",
                "🐔","🐧","🐦","🐤","🦆","🦅","🦉","🦇",
                "🐺","🐗","🐴","🦄","🐝","🦋","🐌","🐞"
            ),

            "🌳" to listOf(
                "🌳","🌲","🌴","🌵","🌱","🌿","☘️","🍀",
                "🍁","🍂","🍃","🌾","🌺","🌻","🌹","🥀",
                "🌷","🌼","🌸","💐","🌞","🌝","🌛","🌜",
                "🌚","🌕","🌙","⭐","🌟","✨","⚡","🔥",
                "🌈","☀️","⛅","🌧️","⛈️","❄️","☃️","🌊"
            ),

            "🍎" to listOf(
                "🍎","🍏","🍊","🍋","🍌","🍉","🍇","🍓",
                "🫐","🍈","🍒","🍑","🥭","🍍","🥥","🥝",
                "🍅","🍆","🥑","🥦","🥬","🥒","🌶️","🌽",
                "🥕","🧄","🧅","🥔","🍠","🥐","🍞","🥖",
                "🧀","🥚","🍳","🥞","🧇","🥓","🍔","🍟",
                "🍕","🌭","🥪","🌮","🌯","🍜","🍝","🍣"
            ),

            "🏠" to listOf(
                "🏠","🏡","🏢","🏬","🏣","🏥","🏦","🏨",
                "🏩","🏪","🏫","🏭","🏛️","⛪","🕌","🛕",
                "⛩️","🕍","⛺","🏕️","🏖️","🏝️","🏜️","🌋",
                "⛰️","🏔️","🗻","🏞️","🌅","🌄","🌇","🌆"
            ),

            "🚗" to listOf(
                "🚗","🚕","🚙","🚌","🚎","🏎️","🚓","🚑",
                "🚒","🚐","🛻","🚚","🚛","🚜","🛵","🏍️",
                "🚲","🛴","🚂","🚆","🚇","🚊","✈️","🛫",
                "🛬","🚁","🚀","🛸","🚢","⛵","🛶","⚓"
            ),

            "⚽" to listOf(
                "⚽","🏀","🏈","⚾","🥎","🎾","🏐","🏉",
                "🥏","🎱","🪀","🏓","🏸","🏒","🏑","🥍",
                "🏏","🪃","🥅","⛳","🪁","🏹","🎣","🤿",
                "🥊","🥋","🎽","🛹","🛼","⛸️","🥌","🎿"
            ),

            "❤️" to listOf(
                "❤️","🧡","💛","💚","💙","💜","🖤","🤍",
                "🤎","🩷","🩵","🩶","💔","❣️","💕","💞",
                "💓","💗","💖","💘","💝","💟","♥️","💌"
            ),

            "💻" to listOf(
                "⌚","📱","📲","💻","⌨️","🖥️","🖨️","🖱️",
                "🖲️","💽","💾","💿","📀","📷","📸","📹",
                "🎥","📺","📻","🎙️","🎚️","🎛️","📞","☎️",
                "📟","📠","🔋","🪫","🔌","💡","🔦","🕯️"
            ),

            "🏳️" to listOf(
                "🏳️","🏴","🏁","🚩","🏳️‍🌈","🏳️‍⚧️",
                "🇲🇲","🇺🇸","🇬🇧","🇹🇭","🇨🇳","🇯🇵",
                "🇰🇷","🇮🇳","🇸🇬","🇲🇾","🇮🇩","🇵🇭",
                "🇦🇺","🇨🇦","🇫🇷","🇩🇪","🇧🇷","🇳🇿"
            )
        )

        // Messenger-style Unicode emoji expansion (keeps the original emoji and order)
        categories["😀"] = (categories["😀"]!! + listOf(
            "🫠","🫣","🫢","🫡","🫥","🫤","🥹","🥲","🥸","🤠",
            "🤯","🥶","🥵","🥴","🤮","🤧","🤒","🤕","🤢","🥱",
            "😵‍💫","😵","🤬","😶‍🌫️","🫨","🫦","🫀","🧠","🦷","🦴",
            "👹","👺","👾","🧟","🧛","🧌","🧙","🧚","🧞","🧜"
        )).distinct()

        categories["👋"] = (categories["👋"]!! + listOf(
            "🫱","🫲","🫳","🫴","🫷","🫸","🫵","🫶","🤲","👐",
            "👋🏻","👋🏼","👋🏽","👋🏾","👋🏿",
            "👍🏻","👍🏼","👍🏽","👍🏾","👍🏿",
            "👎🏻","👎🏼","👎🏽","👎🏾","👎🏿",
            "👏🏻","👏🏼","👏🏽","👏🏾","👏🏿",
            "🙏🏻","🙏🏼","🙏🏽","🙏🏾","🙏🏿",
            "💪🏻","💪🏼","💪🏽","💪🏾","💪🏿",
            "✍🏻","✍🏼","✍🏽","✍🏾","✍🏿",
            "🤘🏻","🤘🏼","🤘🏽","🤘🏾","🤘🏿",
            "🤙🏻","🤙🏼","🤙🏽","🤙🏾","🤙🏿",
            "🫰🏻","🫰🏼","🫰🏽","🫰🏾","🫰🏿"
        )).distinct()

        categories["👨"] = (categories["👨"]!! + listOf(
            "🧑‍🦰","🧑‍🦱","🧑‍🦳","🧑‍🦲","👱","👱‍♀️","👱‍♂️","🧔‍♀️","🧔‍♂️",
            "🤰","🫃","🫄","🤱","🧑‍🍼","👼","🎅","🤶","🧑‍🎄","🥷",
            "🦸","🦹","🧙","🧚","🧛","🧜","🧝","🧞","🧟","💆","💇",
            "🧖","💅","🧘","🛀","🛌","🧍","🧎","🚶","🏃","💃","🕺",
            "🧑‍🤝‍🧑","👭","👫","👬","💏","💑",
            "👨‍👩‍👦","👨‍👩‍👧","👨‍👩‍👧‍👦","👨‍👨‍👦","👨‍👨‍👧","👩‍👩‍👦","👩‍👩‍👧","👩‍👩‍👧‍👦",
            "👨‍👦","👨‍👧","👩‍👦","👩‍👧","👨‍👧‍👦","👩‍👧‍👦",
            "👮‍♀️","👮‍♂️","👷‍♀️","👷‍♂️","💂‍♀️","💂‍♂️","🕵️‍♀️","🕵️‍♂️",
            "👩‍⚖️","👨‍⚖️","👩‍🌾","👨‍🌾","👩‍🍳","👨‍🍳","👩‍🔧","👨‍🔧",
            "👩‍🏭","👨‍🏭","👩‍🚒","👨‍🚒","👩‍✈️","👨‍✈️","👩‍🚀","👨‍🚀",
            "👩‍🎤","👨‍🎤","👩‍🎨","👨‍🎨","👩‍🎓","👨‍🎓","👩‍🏫","👨‍🏫",
            "👩‍💼","👨‍💼","👩‍🔬","👨‍🔬","👩‍💻","👨‍💻","👩‍⚕️","👨‍⚕️"
        )).distinct()

        categories["🐶"] = (categories["🐶"]!! + listOf(
            "🐢","🐍","🦎","🐊","🐉","🐲","🦕","🦖","🐙","🦑","🦐","🦞",
            "🦀","🐡","🐠","🐟","🐬","🐳","🐋","🦈","🪼","🪸","🦭","🦦",
            "🦥","🦨","🦡","🦫","🦔","🦘","🦙","🦒","🦓","🦍","🦧","🦣",
            "🦏","🦛","🐪","🐫","🦬","🦌","🦃","🦚","🦜","🪿","🦢","🦩",
            "🦤","🪲","🪳","🦟","🪰","🪱","🦗","🕷️","🦂","🕸️","🦇","🦥"
        )).distinct()

        categories["🌳"] = (categories["🌳"]!! + listOf(
            "🌍","🌎","🌏","🌐","🌑","🌒","🌓","🌔","🌖","🌗","🌘","🌚",
            "🌝","🌞","🌬️","💨","🌪️","🌫️","☁️","🌤️","🌥️","🌦️","🌨️","🌩️",
            "☔","💧","💦","🫧","🌡️","🪨","🪵","🪹","🪺","🌰","🪷","🪻",
            "🪴","🪸","🍄","🌋","🌀","🌊"
        )).distinct()

        categories["🍎"] = (categories["🍎"]!! + listOf(
            "🍚","🍙","🍘","🍛","🍲","🥘","🍱","🥟","🥠","🍤","🦪","🥮",
            "🫓","🥨","🥯","🥣","🫕","🥗","🧆","🥙","🧈","🧂","🥫","🫙",
            "🥛","🍼","☕","🍵","🧃","🥤","🧋","🍺","🍻","🍷","🥂","🍸",
            "🍹","🥃","🧉","🍶","🍰","🎂","🧁","🍮","🍭","🍬","🍫","🍿",
            "🍩","🍪","🥧","🍯","🫖","🧊","🥡","🍢","🍡","🍦","🍨","🍧"
        )).distinct()

        categories["🏠"] = (categories["🏠"]!! + listOf(
            "🛋️","🪑","🛏️","🛌","🚪","🪟","🪞","🛁","🚿","🧻","🧼","🪥",
            "🧽","🧹","🧺","🪣","🧯","🛠️","🔧","🔨","🪚","🔩","⚙️","🧰",
            "🪛","🔑","🗝️","🧲","🪜","🪤","🧱","🪵","🪨","🛒","🧳","🪧"
        )).distinct()

        categories["🚗"] = (categories["🚗"]!! + listOf(
            "🚄","🚅","🚈","🚉","🚝","🚞","🚋","🚃","🚟","🚠","🚡","🛞",
            "⛽","🛣️","🛤️","🛳️","🛥️","🛩️","🪂","🛰️","🚏","🚦","🚥","🚧",
            "🛑","🛟","🛝","🛺","🚍","🚔","🚖","🚘","🚜","🚲","🛴","🛹"
        )).distinct()

        categories["⚽"] = (categories["⚽"]!! + listOf(
            "🏆","🥇","🥈","🥉","🏅","🎖️","🎗️","🏌️","🏄","🚣","🚴","🏊",
            "🤸","🤼","🤽","🤾","⛹️","🏋️","🧘","🏇","🤺","🧗","🥇","🥈",
            "🥉","🎯","🎳","🎮","🎲","♟️","🧩","🪁"
        )).distinct()

        categories["❤️"] = (categories["❤️"]!! + listOf(
            "❤️‍🔥","❤️‍🩹","💖","💘","💝","💟","💕","💞","💓","💗","💌"
        )).distinct()

        categories["💻"] = (categories["💻"]!! + listOf(
            "📚","📖","📕","📗","📘","📙","📓","📒","📔","📃","📜","📄",
            "📰","🗞️","📑","🔖","🏷️","✏️","✒️","🖋️","🖊️","🖌️","🖍️","📝",
            "📎","🖇️","📐","📏","🧮","📦","🎁","🎈","🎉","🎊","🎀","🪅",
            "🪩","🎵","🎶","🎤","🎧","🎼","🎹","🥁","🎸","🎺","🎻","🎷",
            "🪇","🪈","🔮","🧿","🪬","💎","💰","💵","💴","💶","💷","💳","🪙",
            "🧸","🪆","🪄","🧨","🕹️","📯","🔔","🔕","📢","📣","🔍","🔎"
        )).distinct()

        // Add country flags from ISO-style two-letter region codes.
        fun countryFlag(code: String): String = code.uppercase().map { ch ->
            String(Character.toChars(0x1F1E6 + (ch - 'A')))
        }.joinToString("")
        val extraFlagCodes = listOf(
            "AF","AL","DZ","AD","AO","AG","AR","AM","AT","AZ","BS","BH","BD","BB","BY","BE","BZ","BJ","BT","BO","BA","BW","BN","BG","KH","CM","CL","CO","CR","HR","CU","CY","CZ","DK","DM","DO","EC","EG","SV","EE","ET","FJ","FI","GE","GH","GR","GD","GT","GY","HT","HN","HK","HU","IS","IR","IQ","IE","IL","IT","JM","JO","KZ","KE","KW","KG","LA","LV","LB","LS","LR","LY","LI","LT","LU","MO","MG","MW","MV","ML","MT","MU","MX","MC","MN","ME","MA","MZ","NA","NP","NL","NI","NE","NG","MK","NO","OM","PK","PA","PG","PY","PE","PL","PT","PR","QA","RO","RU","RW","SA","SN","RS","SC","SL","SK","SI","SO","ZA","ES","LK","SD","SR","SE","CH","SY","TW","TJ","TZ","TN","TR","TM","UG","UA","AE","UY","UZ","VE","VN","YE","ZM","ZW","PS","XK"
        )
        categories["🏳️"] = (categories["🏳️"]!! + extraFlagCodes.map { countryFlag(it) }).distinct()

        root.removeAllViews()

        // Emoji content area
        val emojiArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        // Vertical scroll area
        val emojiScroll = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = false
            isSmoothScrollingEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            isNestedScrollingEnabled = false
            clipChildren = true
            clipToPadding = true
        }

        // Fixed category bar
        val categoryBar = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = false
        }

        val categoryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        for ((category, emojis) in categories) {

            val button = Button(this).apply {
                text = category
                textSize = 21f
                isAllCaps = false
                minWidth = 0
                minHeight = 0
                setPadding(dp(9), dp(3), dp(9), dp(3))

                background = GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = dp(12).toFloat()
                }
            }

            val params = LinearLayout.LayoutParams(
                dp(48),
                dp(43)
            )

            params.setMargins(dp(2), dp(2), dp(2), dp(2))
            categoryRow.addView(button, params)

            button.setOnClickListener {
                selectedEmojiCategory = category

                showEmojiCategory(emojis, emojiArea)

                emojiScroll.scrollTo(0, 0)
            }
        }

        categoryBar.addView(categoryRow)

        emojiScroll.addView(
            emojiArea,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // 1. Category bar - fixed height
        root.addView(
            categoryBar,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(47)
            )
        )

        // 2. Emoji list - takes remaining height
        root.addView(
            emojiScroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        // 3. Show selected category
        showEmojiCategory(
            categories[selectedEmojiCategory] ?: categories["😀"]!!,
            emojiArea
        )

        // 4. Bottom buttons - fixed position
        addRow(listOf("ABC", "GLOBE", "BACK"))

    } // showEmojiPanel() ကို ပိတ်ရန်

        // SHOW EMOJI CATEGORY
    private fun showEmojiCategory(
        emojis: List<String>,
        emojiArea: LinearLayout
    ) {
        emojiArea.removeAllViews()

        for (group in emojis.chunked(7)) {

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }

            for (emoji in group) {

                val button = Button(this).apply {
                    text = emoji
                    textSize = 22f
                    isAllCaps = false
                    minWidth = 0
                    minHeight = 0
                    setPadding(0, 0, 0, 0)

                    background = GradientDrawable().apply {
                        setColor(Color.WHITE)
                        cornerRadius = dp(8).toFloat()
                    }
                }

                val params = LinearLayout.LayoutParams(
                    0,
                    dp(43),
                    1f
                )

                params.setMargins(dp(1), dp(1), dp(1), dp(1))
                row.addView(button, params)

                button.setOnClickListener {
                    currentInputConnection?.commitText(emoji, 1)
                }
            }

            emojiArea.addView(
                row,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(45)
                )
            )
        }
    }

    // SYMBOL KEYBOARD
    private fun showSymbolPanel() {

        if (shiftState == 0) {

            // Shift OFF
            addRow(listOf(
                "1","2","3","4","5",
                "6","7","8","9","0"
            ))

            addRow(listOf(
                "@","#","$","%","&",
                "-","+","(",")","/"
            ))

            addRow(listOf(
                "*","\"","'",":",";",
                "!","?","=","_"
            ))
        } else {

            // Shift ON
            addRow(listOf(
                "~","`","|","•","√",
                "π","÷","×","§","∆"
            ))

            addRow(listOf(
                "£","¢","€","¥","^",
                "°","=","{","}","\\"
            ))

            addRow(listOf(
                "%","©","®","™","✓",
                "[","]","<",">"
            ))
        }

        // Bottom control row
        addRow(listOf("SHIFT", "ABC", "EMOJI", "BACK"))
    }
    // HANDLE KEY



    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return

        when (key) {



            "SHIFT" -> {
                if (mode == Mode.SYMBOLS) {
                    shiftState = if (shiftState == 0) 1 else 0
                } else {
                    val now = SystemClock.uptimeMillis()

                    shiftState = when {
                        shiftState == 2 -> 0
                        shiftState == 1 && now - lastShiftTap < 800 -> 2
                        shiftState == 1 -> 0
                        else -> 1
                    }

                    lastShiftTap = now
                }

                refreshKeyboard()
            }




            "BACK" -> {

                val selectedText = ic.getSelectedText(0)

                if (!selectedText.isNullOrEmpty()) {

                    ic.commitText("", 1)

                } else {

                    if (mode == Mode.KCHO) {

                        val before = ic.getTextBeforeCursor(20, 0)
                            ?.toString() ?: ""

                        val specialKeys = listOf(
                            "Hng", "Phl", "Phy",
                            "k'", "m'", "ng'", "py",
                            "K'", "M'", "Ng'"
                        )

                        val matchedKey = specialKeys.firstOrNull {
                            before.endsWith(it)
                        }

                        if (matchedKey != null) {

                            val count = matchedKey.codePointCount(
                                0,
                                matchedKey.length
                            )

                            ic.deleteSurroundingTextInCodePoints(count, 0)

                        } else {

                            ic.deleteSurroundingTextInCodePoints(1, 0)
                        }

                    } else {

                        ic.deleteSurroundingTextInCodePoints(1, 0)
                    }
                }
            }

            "ENTER" -> {
                ic.commitText("\n", 1)
                consumeOneShotShift()
            }

            "SPACE" -> {
                val before = ic.getTextBeforeCursor(100, 0)
                    ?.toString() ?: ""

                val word = before
                    .substringAfterLast(" ")
                    .substringAfterLast("\n")
                    .trim()

                if (word.isNotEmpty()) {
                    personalDictionary.addWord(word)
                }

                ic.commitText(" ", 1)
                consumeOneShotShift()
            }

            "COMMA" -> {
                ic.commitText(
                    if (mode == Mode.MYANMAR) "၊" else ",", 1
                )
                consumeOneShotShift()
            }

            "PERIOD" -> {
                ic.commitText(
                    if (mode == Mode.MYANMAR) "။" else ".", 1
                )
                consumeOneShotShift()
            }

            "GLOBE" -> {
                mode = when (mode) {
                    Mode.KCHO -> Mode.ENGLISH
                    Mode.ENGLISH -> Mode.MYANMAR
                    else -> Mode.KCHO
                }

                shiftState = 0
                refreshKeyboard()
            }

            "EMOJI" -> {
                emojiPreviousMode = mode
                mode = Mode.EMOJI
                selectedEmojiCategory = "😀"
                shiftState = 0
                refreshKeyboard()
            }

            "SYMBOL" -> {
                if (mode != Mode.SYMBOLS) {
                    previousMode = mode
                }

                mode = Mode.SYMBOLS
                shiftState = 0
                refreshKeyboard()
            }

            "ABC" -> {
                mode = if (mode == Mode.EMOJI) {
                    Mode.SYMBOLS
                } else {
                    previousMode
                }

                shiftState = 0
                refreshKeyboard()
            }

            else -> {
                val output = when (mode) {

                    Mode.MYANMAR -> {
                        val map = if (shiftState > 0) myShift else myNormal
                        map[key] ?: key
                    }

                    Mode.KCHO -> {
                        when (key) {
                            "q" -> if (shiftState > 0) "Ä" else "ä"
                            "z" -> if (shiftState > 0) "Ü" else "ü"
                            "ë" -> if (shiftState > 0) "Ë" else "ë"

                            "k'", "m'", "ng'", "py",
                            "K'", "M'", "Ng'", "Hng", "Phl", "Phy" -> key

                            "1", "2", "3", "4", "5",
                            "6", "7", "8", "9", "0" -> key

                            else -> {
                                if (shiftState > 0) key.uppercase()
                                else key.lowercase()
                            }
                        }
                    }

                    Mode.ENGLISH -> {
                        if (shiftState > 0) key.uppercase()
                        else key.lowercase()
                    }

                    else -> key
                }

                if (mode == Mode.MYANMAR) {
                    val before = ic.getTextBeforeCursor(8, 0)?.toString() ?: ""

                    if (output == "ု" && before.endsWith("ံ")) {
                        ic.deleteSurroundingText(1, 0)
                        ic.commitText("ုံ", 1)
                    } else {
                        myanmarInputEngine.insert(ic, output)
                    }
                } else {
                    ic.commitText(output, 1)
                }

                consumeOneShotShift()
            }
        }

        updateTopToolbarSuggestions()
    }


    private fun consumeOneShotShift() {
        if (shiftState == 1) {
            shiftState = 0
            refreshKeyboard()
        }
    }

    // PUNCTUATION POPUP
    private fun showPunctuationPopup(anchor: View) {

        val symbols = listOf(
            "&", "%", "+", "\"", "-", ":",
            "'", "@", ";", "/", "(", ")",
            "#", "!", ",", "?"
        )

        val popup = PopupWindow(this)
        val container = LinearLayout(this)

        container.orientation = LinearLayout.VERTICAL
        container.setPadding(dp(4), dp(4), dp(4), dp(4))
        container.setBackgroundColor(Color.rgb(220, 235, 250))

        for (group in symbols.chunked(4)) {

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL

            for (symbol in group) {

                val button = Button(this)
                button.text = symbol
                button.isAllCaps = false
                button.textSize = 18f
                button.setTextColor(Color.rgb(21, 87, 145))
                button.backgroundTintList =
                    ColorStateList.valueOf(Color.WHITE)

                button.minWidth = 0
                button.minHeight = 0
                button.setPadding(0, 0, 0, 0)

                val params = LinearLayout.LayoutParams(
                    0, dp(43), 1f
                )

                params.setMargins(dp(2), dp(2), dp(2), dp(2))
                row.addView(button, params)

                button.setOnClickListener {
                    currentInputConnection?.commitText(symbol, 1)
                    consumeOneShotShift()
                    popup.dismiss()
                }
            }

            container.addView(row)
        }

        popup.contentView = container
        popup.width = dp(230)
        popup.height = ViewGroup.LayoutParams.WRAP_CONTENT
        popup.isFocusable = true
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        popup.showAsDropDown(anchor, 0, -dp(190))
    }

    // REFRESH KEYBOARD
    private fun refreshKeyboard() {
        setInputView(buildKeyboard())
    }
}