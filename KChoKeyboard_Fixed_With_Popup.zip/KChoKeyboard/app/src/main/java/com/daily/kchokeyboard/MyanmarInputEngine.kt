package com.daily.kchokeyboard

import android.view.inputmethod.InputConnection

class MyanmarInputEngine {

    private var pendingPreVowel = false

    fun insert(ic: InputConnection, output: String) {

        val before = ic.getTextBeforeCursor(16, 0)?.toString() ?: ""

        val last = before.lastOrNull()

        val isMyanmarConsonant = output.length == 1 &&
                output[0].code in 0x1000..0x1021

        val isMedial = output in listOf("ျ", "ြ", "ွ", "ှ")

        when {
            // ေ ကို ရိုက်သောအခါ
            output == "ေ" -> {
                ic.commitText(output, 1)

                pendingPreVowel = true
            }

            // ေ နောက်တွင် ဗျည်းရိုက်သောအခါ
            isMyanmarConsonant &&
                    pendingPreVowel &&
                    before.endsWith("ေ") -> {

                ic.deleteSurroundingText(1, 0)
                ic.commitText(output + "ေ", 1)

                pendingPreVowel = false
            }

            // ေ နောက်တွင် ျ ြ ွ ှ ရိုက်သောအခါ
            isMedial && before.endsWith("ေ") -> {

                ic.deleteSurroundingText(1, 0)
                ic.commitText(output + "ေ", 1)

                pendingPreVowel = false
            }

            else -> {
                ic.commitText(output, 1)

                if (output.isNotEmpty()) {
                    pendingPreVowel = false
                }
            }
        }
    }

    fun reset() {
        pendingPreVowel = false
    }
}

