package com.daily.kchokeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    companion object {
        private const val PICK_BACKGROUND = 1001
        private const val PREFS_NAME = "kcho_keyboard_settings"

    }

    private val prefs by lazy {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private lateinit var content: LinearLayout
    private lateinit var themePreview: FrameLayout
    private lateinit var settingsScroll: ScrollView
    private lateinit var themeSectionStart: View
    private lateinit var imageOpacitySeekBar: SeekBar
    private lateinit var keyboardOpacitySeekBar: SeekBar
    private lateinit var keyOpacitySeekBar: SeekBar

    private val colorDefaults = linkedMapOf(
        "theme_keyboard_bg_color" to Color.rgb(220, 235, 250),
        "theme_key_bg_color" to Color.WHITE,
        "theme_key_text_color" to Color.rgb(39, 101, 220),
        "theme_special_key_bg_color" to Color.rgb(39, 101, 220),
        "theme_special_icon_color" to Color.WHITE,
        "theme_toolbar_bg_color" to Color.rgb(220, 235, 250),
        "theme_toolbar_icon_color" to Color.rgb(39, 101, 220),
        "theme_key_border_color" to Color.LTGRAY,
        "theme_key_shadow_color" to Color.GRAY
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(220, 235, 250))
            setPadding(dp(16), dp(12), dp(16), dp(20))
        }

        val title = TextView(this).apply {
            text = "K'Cho Keyboard Settings"
            textSize = 23f
            setTextColor(Color.rgb(35, 83, 155))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(14))
        }
        root.addView(title)

        settingsScroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        settingsScroll.addView(content)
        root.addView(settingsScroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        addPreferenceSection()
        addThemeSection()
        addCustomColorsSection()
        addCorrectionSection()
        addAboutSection()

        setContentView(root)

        if (intent.getBooleanExtra("open_theme", false)) {
            settingsScroll.post {
                settingsScroll.smoothScrollTo(0, themeSectionStart.top)
            }
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun addHeading(text: String) {
        val view = TextView(this).apply {
            this.text = text
            textSize = 19f
            setTextColor(Color.rgb(35, 83, 155))
            setPadding(0, dp(20), 0, dp(8))
        }
        content.addView(view)
    }

    private fun addInfo(text: String) {
        val view = TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(4), 0, dp(10))
        }
        content.addView(view)
    }

    private fun addPreferenceSection() {
        addHeading("Preferences")
        addSwitch("Sound", "sound_enabled", true)
        addSwitch("Vibration", "vibration_enabled", true)

        val fontLabel = TextView(this).apply {
            text = "Font Size"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(12), 0, dp(5))
        }
        content.addView(fontLabel)

        val fontValue = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(39, 101, 220))
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(2))
        }

        val fontSeekBar = SeekBar(this).apply {
            max = 10 // 12–22
            progress = (prefs.getInt("font_size_value", 20) - 12)
                .coerceIn(0, 10)
        }

        fun updateFontValue(value: Int) {
            fontValue.text = "Font Size: $value"
        }

        updateFontValue(fontSeekBar.progress + 12)
        fontSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar?,
                progress: Int,
                fromUser: Boolean
            ) {
                val value = progress + 12
                updateFontValue(value)
                prefs.edit().putInt("font_size_value", value).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        content.addView(fontValue)
        content.addView(fontSeekBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(42)
        ))

        addInfo("Adjust keyboard letter size from 12 to 22. Special characters keep their preset sizes.")
    }



    private fun addThemeSection() {
        addHeading("Theme")
        themeSectionStart = content.getChildAt(content.childCount - 1)
        addInfo("My Theme — preview your keyboard appearance below.")

        themePreview = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(190, 210, 230))
            clipToPadding = true
            clipChildren = true
        }

        content.addView(
            themePreview,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(190)
            ).apply { setMargins(0, dp(4), 0, dp(12)) }
        )

        refreshThemePreview()

        // Size Preview Sliders
        addSizePreviewSeekBar("Shift Icon Size", "preview_shift_size", 100)
        addSizePreviewSeekBar("123? Text Size", "preview_symbol_size", 100)
        addSizePreviewSeekBar("Enter Icon Size", "preview_enter_size", 100)

        // Background Image
        addActionButton("Choose Background Image") {
            val pickerIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )
            }
            startActivityForResult(pickerIntent, PICK_BACKGROUND)
        }

        // Transparency Sliders
        addSeekBar("Background Image Opacity", "background_opacity", 100).also {
            imageOpacitySeekBar = it
        }
        addSeekBar("Keyboard Background Transparency", "keyboard_bg_opacity", 100).also {
            keyboardOpacitySeekBar = it
        }
        addSeekBar("Key Button Transparency", "key_opacity", 100).also {
            keyOpacitySeekBar = it
        }

        // Apply Theme
        addActionButton("Apply Theme") {
            prefs.edit()
                .putInt("theme_shift_size", prefs.getInt("preview_shift_size", 100))
                .putInt("theme_symbol_size", prefs.getInt("preview_symbol_size", 100))
                .putInt("theme_enter_size", prefs.getInt("preview_enter_size", 100))
                .putBoolean("theme_applied", true)
                .apply()

            refreshThemePreview()
            Toast.makeText(this, "Theme applied", Toast.LENGTH_SHORT).show()
        }

        // Remove Background Image
        addActionButton("Remove Background Image") {
            prefs.edit()
                .remove("background_image_uri")
                .putBoolean("theme_applied", false)
                .putInt("background_opacity", 100)
                .apply()

            if (::imageOpacitySeekBar.isInitialized) {
                imageOpacitySeekBar.progress = 100
            }
            refreshThemePreview()
            Toast.makeText(this, "Background image removed", Toast.LENGTH_SHORT).show()
        }

        // Restore Default
        addActionButton("Restore Default") {
            AlertDialog.Builder(this)
                .setTitle("Restore Default Theme?")
                .setMessage(
                    "This will restore the original colors and transparency settings, and remove the background image."
                )
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Restore") { _, _ -> restoreDefaultTheme() }
                .show()
        }
    }

    private fun addSeekBar(label: String, preferenceKey: String, defaultValue: Int): SeekBar {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(4))
        }
        val valueText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.DKGRAY)
        }
        val seekBar = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt(preferenceKey, defaultValue).coerceIn(0, 100)
        }
        fun updateLabel(value: Int) {
            valueText.text = "$label: $value%"
        }
        updateLabel(seekBar.progress)
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateLabel(progress)
                prefs.edit().putInt(preferenceKey, progress).apply()
                refreshThemePreview()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        wrapper.addView(valueText)
        wrapper.addView(seekBar)
        content.addView(wrapper)
        return seekBar
    }

    private fun addSizePreviewSeekBar(
        label: String,
        previewKey: String,
        defaultValue: Int = 100
    ): SeekBar {

        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(4))
        }

        val valueText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.DKGRAY)
        }

        val seekBar = SeekBar(this).apply {
            max = 100
            progress = (
                    prefs.getInt(previewKey, defaultValue) - 50
                    ).coerceIn(0, 100)
        }

        fun updateLabel(progress: Int) {
            valueText.text = "$label: ${progress + 50}%"
        }

        updateLabel(seekBar.progress)

        seekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    val value = progress + 50

                    updateLabel(progress)

                    prefs.edit()
                        .putInt(previewKey, value)
                        .apply()

                    refreshThemePreview()
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
        )

        wrapper.addView(valueText)
        wrapper.addView(seekBar)
        content.addView(wrapper)

        return seekBar
    }


    private fun refreshThemePreview() {
        if (!::themePreview.isInitialized) return
        themePreview.removeAllViews()

        val imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            val uriText = prefs.getString("background_image_uri", null)
            if (!uriText.isNullOrEmpty()) {
                try { setImageURI(Uri.parse(uriText)) } catch (_: Exception) { setImageDrawable(null) }
            }
            alpha = prefs.getInt("background_opacity", 100).coerceIn(0, 100) / 100f
        }
        themePreview.addView(imageView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val keyboardColor = prefs.getInt("theme_keyboard_bg_color", colorDefaults.getValue("theme_keyboard_bg_color"))
        val keyboardAlpha = prefs.getInt("keyboard_bg_opacity", 100).coerceIn(0, 100)
        val overlay = View(this).apply {
            background = ColorDrawable(keyboardColor).apply { alpha = keyboardAlpha * 255 / 100 }
        }
        themePreview.addView(overlay, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val previewKeyboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(6), dp(5), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = dp(10).toFloat()
            }
        }
        val shiftSize = prefs.getInt("preview_shift_size", 100) / 100f
        val symbolSize = prefs.getInt("preview_symbol_size", 100) / 100f
        val enterSize = prefs.getInt("preview_enter_size", 100) / 100f
        val rows = listOf(
            listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
            listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
            listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫"),
            listOf("?123", ",", "K'Cho", ".", "↵")
        )
        rows.forEachIndexed { rowIndex, labels ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            labels.forEach { label ->
                val special = label in listOf("⇧", "⌫", "?123", "↵")
                val keyColor = if (special) {
                    prefs.getInt("theme_special_key_bg_color", colorDefaults.getValue("theme_special_key_bg_color"))
                } else {
                    prefs.getInt("theme_key_bg_color", Color.WHITE)
                }
                val opacity = prefs.getInt("key_opacity", 100).coerceIn(0, 100)
                val key = TextView(this).apply {
                    text = label
                    gravity = Gravity.CENTER
                    textSize = when (label) {
                        "K'Cho" -> 10f
                        "⇧" -> 12f * shiftSize
                        "?123" -> 12f * symbolSize
                        "↵" -> 12f * enterSize
                        else -> 12f
                    }
                    setTextColor(if (special) {
                        prefs.getInt("theme_special_icon_color", Color.WHITE)
                    } else {
                        prefs.getInt("theme_key_text_color", Color.rgb(39, 101, 220))
                    })
                    background = GradientDrawable().apply {
                        setColor(withOpacity(keyColor, opacity))
                        cornerRadius = dp(5).toFloat()
                        setStroke(dp(1), withOpacity(
                            prefs.getInt("theme_key_border_color", Color.LTGRAY), opacity
                        ))
                    }
                    elevation = dp(1).toFloat()
                }
                val weight = when {
                    rowIndex == 3 && label == "K'Cho" -> 2.4f
                    rowIndex == 3 && label in listOf("?123", "↵") -> 1.35f
                    else -> 1f
                }
                row.addView(key, LinearLayout.LayoutParams(0, dp(32), weight).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                })
            }
            previewKeyboard.addView(row)
        }
        themePreview.addView(previewKeyboard, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        ))
    }

    private fun withOpacity(color: Int, opacity: Int): Int {
        val alpha = Color.alpha(color) * opacity.coerceIn(0, 100) / 100
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    }

    private fun restoreDefaultTheme() {
        val editor = prefs.edit()
        colorDefaults.forEach { (key, value) -> editor.putInt(key, value) }
        editor.remove("background_image_uri")
            .putBoolean("theme_applied", false)
            .putInt("background_opacity", 100)
            .putInt("keyboard_bg_opacity", 100)
            .putInt("key_opacity", 100)
            .putInt("preview_shift_size", 100)
            .putInt("preview_symbol_size", 100)
            .putInt("preview_enter_size", 100)
            .putInt("theme_shift_size", 100)
            .putInt("theme_symbol_size", 100)
            .putInt("theme_enter_size", 100)
            .apply()

        if (::imageOpacitySeekBar.isInitialized) imageOpacitySeekBar.progress = 100
        if (::keyboardOpacitySeekBar.isInitialized) keyboardOpacitySeekBar.progress = 100
        if (::keyOpacitySeekBar.isInitialized) keyOpacitySeekBar.progress = 100
        refreshThemePreview()
        recreate()
        Toast.makeText(this, "Default theme restored", Toast.LENGTH_SHORT).show()
    }

    private fun addCustomColorsSection() {
        addHeading("Theme Studio — Custom Colors")
        addInfo("Choose your own keyboard colors. Background image and transparency settings are kept separately.")

        val palette = intArrayOf(
            Color.WHITE, Color.BLACK, Color.RED, Color.GREEN, Color.BLUE,
            Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.GRAY, Color.LTGRAY,
            Color.DKGRAY, Color.rgb(220, 235, 250), Color.rgb(39, 101, 220),
            Color.rgb(255, 152, 0), Color.rgb(76, 175, 80), Color.rgb(156, 39, 176),
            Color.rgb(0, 150, 136), Color.rgb(233, 30, 99), Color.rgb(121, 85, 72),
            Color.rgb(63, 81, 181)
        )

        fun colorHex(color: Int) = String.format("#%08X", color)

        fun makeSwatch(color: Int): GradientDrawable = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(8).toFloat()
            setStroke(dp(1), Color.LTGRAY)
        }

        fun addColorOption(title: String, key: String, defaultColor: Int) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = dp(10).toFloat()
                }
                isClickable = true
                isFocusable = true
            }
            val label = TextView(this).apply {
                text = title
                textSize = 14f
                setTextColor(Color.DKGRAY)
            }
            row.addView(label, LinearLayout.LayoutParams(0, dp(42), 1f))

            val swatch = View(this).apply {
                background = makeSwatch(prefs.getInt(key, defaultColor))
                isClickable = false
            }
            row.addView(swatch, LinearLayout.LayoutParams(dp(48), dp(34)))

            row.setOnClickListener {
                val dialogContent = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), dp(12), dp(12), dp(8))
                }
                val hexInput = EditText(this).apply {
                    hint = "#RRGGBB or #AARRGGBB"
                    setSingleLine(true)
                    setText(colorHex(prefs.getInt(key, defaultColor)))
                }
                val paletteGrid = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }

                lateinit var colorDialog: AlertDialog
                palette.toList().chunked(5).forEach { group ->
                    val paletteRow = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER
                    }
                    group.forEach { color ->
                        val colorCell = TextView(this).apply {
                            text = if (color == prefs.getInt(key, defaultColor)) "✓" else ""
                            textSize = 18f
                            gravity = Gravity.CENTER
                            setTextColor(if (color == Color.WHITE || color == Color.YELLOW || color == Color.CYAN || color == Color.LTGRAY) Color.BLACK else Color.WHITE)
                            background = GradientDrawable().apply {
                                setColor(color)
                                cornerRadius = dp(7).toFloat()
                                setStroke(dp(1), Color.GRAY)
                            }
                            isClickable = true
                            isFocusable = true
                            contentDescription = "Choose color ${colorHex(color)}"
                            setOnClickListener {
                                prefs.edit().putInt(key, color).apply()
                                swatch.background = makeSwatch(color)
                                refreshThemePreview()
                                colorDialog.dismiss()
                                Toast.makeText(this@SettingsActivity, "$title updated", Toast.LENGTH_SHORT).show()
                            }
                        }
                        paletteRow.addView(colorCell, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                            setMargins(dp(3), dp(3), dp(3), dp(3))
                        })
                    }
                    paletteGrid.addView(paletteRow, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ))
                }

                dialogContent.addView(paletteGrid, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ))
                dialogContent.addView(hexInput, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(8) })

                colorDialog = AlertDialog.Builder(this)
                    .setTitle(title)
                    .setView(dialogContent)
                    .setPositiveButton("Apply HEX", null)
                    .setNegativeButton("Close", null)
                    .create()
                colorDialog.setOnShowListener {
                    colorDialog.window?.setLayout(
                        (resources.displayMetrics.widthPixels * 0.88f).toInt(),
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    colorDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        try {
                            val parsed = Color.parseColor(hexInput.text.toString().trim())
                            prefs.edit().putInt(key, parsed).apply()
                            swatch.background = makeSwatch(parsed)
                            refreshThemePreview()
                            colorDialog.dismiss()
                            Toast.makeText(this@SettingsActivity, "$title updated", Toast.LENGTH_SHORT).show()
                        } catch (_: IllegalArgumentException) {
                            hexInput.error = "Invalid color code"
                        }
                    }
                }
                colorDialog.show()
            }

            content.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dp(3), 0, dp(3)) })
        }

        addColorOption("Keyboard Background", "theme_keyboard_bg_color", colorDefaults.getValue("theme_keyboard_bg_color"))
        addColorOption("Key Button Color", "theme_key_bg_color", colorDefaults.getValue("theme_key_bg_color"))
        addColorOption("Key Text Color", "theme_key_text_color", colorDefaults.getValue("theme_key_text_color"))
        addColorOption("Special Key Color", "theme_special_key_bg_color", colorDefaults.getValue("theme_special_key_bg_color"))
        addColorOption("Special Key Icon Color", "theme_special_icon_color", colorDefaults.getValue("theme_special_icon_color"))
        addColorOption("Toolbar Background", "theme_toolbar_bg_color", colorDefaults.getValue("theme_toolbar_bg_color"))
        addColorOption("Toolbar Icon Color", "theme_toolbar_icon_color", colorDefaults.getValue("theme_toolbar_icon_color"))
        addColorOption("Key Border Color", "theme_key_border_color", colorDefaults.getValue("theme_key_border_color"))
        addColorOption("Key Shadow Color", "theme_key_shadow_color", colorDefaults.getValue("theme_key_shadow_color"))
    }

    private fun addActionButton(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        content.addView(button, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
        ).apply { setMargins(0, dp(4), 0, dp(4)) })
    }


    private fun addCorrectionSection() {
        addHeading("Correction & Suggestions")
        addSwitch("Auto Word Suggestions", "auto_suggestions", true)
        addInfo("Offline Local History and Language Suggestions")
    }


    private fun addAboutSection() {
        addHeading("About")

        addInfo(
            "K'Cho k'chang gui \"K'Choca\" ami guk then nak a ng'hlawi pi vai ah hmawk ah büne shin ah \"K'Cho Keyboard\" cu Ng'Lo Rhing Ling naw 2026 kum ung a pyan ah Kya ci."
        )

        addInfo("Software Name: K'Cho Keyboard")
        addInfo("Software Version: 1.0.0")
        addInfo("Created by Law Shing Ling")
    }


    private fun addSwitch(
        label: String,
        key: String,
        defaultValue: Boolean
    ) {
        val switch = Switch(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.DKGRAY)
            isChecked = prefs.getBoolean(key, defaultValue)

            setOnCheckedChangeListener { _, checked ->
                prefs.edit()
                    .putBoolean(key, checked)
                    .apply()
            }
        }

        content.addView(
            switch,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48)
            )
        )
    }


    @Deprecated("Deprecated in Android, retained for document picker compatibility")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_BACKGROUND && resultCode == RESULT_OK) {

            val uri = data?.data ?: return

            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }

            prefs.edit()
                .putString("background_image_uri", uri.toString())
                .apply()

            refreshThemePreview()

            Toast.makeText(
                this,
                "Background image selected",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
