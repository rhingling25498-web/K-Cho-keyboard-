package com.daily.kchokeyboard

import android.content.Context
import org.json.JSONObject
import java.util.Locale

class PersonalDictionary(context: Context) {

    companion object {
        const val KCHO = "KCHO"
        const val ENGLISH = "ENGLISH"
        const val MYANMAR = "MYANMAR"
    }

    private val appContext = context.applicationContext

    private val prefs = appContext.getSharedPreferences(
        "kcho_personal_dictionary",
        Context.MODE_PRIVATE
    )

    private val maxWords = 5000

    private val assetCache = mutableMapOf<String, List<String>>()

    private fun getDictionaryKey(language: String): String {
        return when (language) {
            ENGLISH -> "saved_words_ENGLISH"
            MYANMAR -> "saved_words_MYANMAR"
            else -> "saved_words_KCHO"
        }
    }

    // K'Cho အတွက် မူလခေါ်ဆိုမှုကို ဆက်ထိန်းထားသည်
    fun addWord(input: String) {
        addWord(input, KCHO)
    }

    // ရိုက်ထားသော စကားလုံးကို သိမ်းမည်
    fun addWord(input: String, language: String) {

        val word = input.trim()

        if (word.isEmpty() || word.length > 64) return
        if (word.any { it.isWhitespace() }) return
        if (word.none { it.isLetterOrDigit() }) return

        val key = getDictionaryKey(language)
        val data = loadDictionary(key)

        val wordKey = word.lowercase(Locale.ROOT)
        val now = System.currentTimeMillis()

        val entry = data.optJSONObject(wordKey) ?: JSONObject()

        entry.put("word", entry.optString("word", word))
        entry.put("count", entry.optInt("count", 0) + 1)
        entry.put("updatedAt", now)

        data.put(wordKey, entry)

        while (data.length() > maxWords) {
            val keys = data.keys().asSequence().toList()

            val oldest = keys.minByOrNull { savedKey ->
                data.optJSONObject(savedKey)
                    ?.optLong("updatedAt", 0L) ?: 0L
            }

            if (oldest != null) {
                data.remove(oldest)
            } else {
                break
            }
        }

        prefs.edit()
            .putString(key, data.toString())
            .apply()
    }

    // မူလခေါ်ဆိုမှုကို ဆက်လက်အသုံးပြုနိုင်သည်
    fun getSuggestions(
        prefix: String,
        limit: Int = 3
    ): List<String> {
        return getSuggestions(prefix, KCHO, limit)
    }

    // ဘာသာစကားအလိုက် အကြံပြုချက်များ
    fun getSuggestions(
        prefix: String,
        language: String,
        limit: Int = 3
    ): List<String> {

        val query = prefix.trim()

        if (query.isEmpty() || limit <= 0) {
            return emptyList()
        }

        // ကိုယ်တိုင်သိမ်းထားသော စကားလုံးများ
        val data = loadDictionary(getDictionaryKey(language))

        val learnedWords = mutableListOf<JSONObject>()
        val keys = data.keys()

        while (keys.hasNext()) {
            val key = keys.next()
            val item = data.optJSONObject(key) ?: continue
            val word = item.optString("word")

            if (
                word.startsWith(query, ignoreCase = true) &&
                word.length > query.length
            ) {
                learnedWords.add(item)
            }
        }

        val learned = learnedWords
            .sortedWith(
                compareByDescending<JSONObject> {
                    it.optInt("count", 0)
                }.thenByDescending {
                    it.optLong("updatedAt", 0L)
                }
            )
            .map { it.optString("word") }

        // K'Cho အတွက် ကိုယ်တိုင်သင်ယူထားသော စကားလုံးများသာ
        if (language == KCHO) {
            return learned.take(limit)
        }

        // English / Myanmar Offline Dictionary
        val builtInWords = loadAssetWords(language)

        val builtIn = builtInWords.filter {
            it.startsWith(query, ignoreCase = true) &&
                    it.length > query.length
        }

        return (learned + builtIn)
            .distinctBy { it.lowercase(Locale.ROOT) }
            .take(limit)
    }

    // Assets ထဲက Dictionary ဖိုင်ကို ဖတ်မည်
    private fun loadAssetWords(language: String): List<String> {

        val fileName = when (language) {
            ENGLISH -> "english_words.txt"
            MYANMAR -> "myanmar_words.txt"
            else -> return emptyList()
        }

        // တစ်ကြိမ်ဖတ်ပြီးရင် Memory ထဲမှာ သိမ်းထားမည်
        synchronized(assetCache) {
            assetCache[fileName]?.let {
                return it
            }

            val words = try {
                appContext.assets.open(fileName)
                    .bufferedReader(Charsets.UTF_8)
                    .useLines { lines ->
                        lines.map { it.trim() }
                            .filter { it.isNotEmpty() }
                            .filter { !it.startsWith("#") }
                            .distinctBy {
                                it.lowercase(Locale.ROOT)
                            }
                            .toList()
                    }
            } catch (e: Exception) {
                e.printStackTrace()
                emptyList()
            }

            assetCache[fileName] = words
            return words
        }
    }

    fun getWordCount(): Int {
        return getWordCount(KCHO)
    }

    fun getWordCount(language: String): Int {
        return loadDictionary(
            getDictionaryKey(language)
        ).length()
    }

    private fun loadDictionary(key: String): JSONObject {

        var saved = prefs.getString(key, null)

        // အရင် K'Cho Dictionary ကို မပျောက်စေရန်
        if (key == "saved_words_KCHO" && saved.isNullOrEmpty()) {
            val oldData = prefs.getString("saved_words", null)

            if (!oldData.isNullOrEmpty()) {
                saved = oldData
                prefs.edit()
                    .putString(key, oldData)
                    .apply()
            }
        }

        return try {
            if (saved.isNullOrEmpty()) {
                JSONObject()
            } else {
                JSONObject(saved)
            }
        } catch (e: Exception) {
            JSONObject()
        }
    }
}

