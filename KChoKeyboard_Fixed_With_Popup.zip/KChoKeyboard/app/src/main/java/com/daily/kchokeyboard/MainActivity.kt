
package com.daily.kchokeyboard

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.graphics.Color
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var enableStatus: TextView
    private lateinit var selectStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        main.gravity = Gravity.CENTER
        main.setPadding(25, 25, 25, 25)
        main.setBackgroundColor(Color.rgb(230, 242, 255))

        val title = TextView(this)
        title.text = "K'Cho Keyboard"
        title.textSize = 28f
        title.setTextColor(Color.rgb(20, 80, 160))
        title.gravity = Gravity.CENTER

        main.addView(title)

        val subtitle = TextView(this)
        subtitle.text = "K'Cho • English • Myanmar"
        subtitle.textSize = 17f
        subtitle.gravity = Gravity.CENTER
        subtitle.setTextColor(Color.DKGRAY)

        main.addView(subtitle)

        enableStatus = TextView(this)
        enableStatus.textSize = 16f
        enableStatus.gravity = Gravity.CENTER
        enableStatus.setPadding(5, 20, 5, 10)

        main.addView(enableStatus)

        val enableButton = Button(this)
        enableButton.text = "ENABLE KEYBOARD"

        main.addView(enableButton)

        selectStatus = TextView(this)
        selectStatus.textSize = 16f
        selectStatus.gravity = Gravity.CENTER
        selectStatus.setPadding(5, 15, 5, 10)

        main.addView(selectStatus)

        val selectButton = Button(this)
        selectButton.text = "SELECT KEYBOARD"

        main.addView(selectButton)

        val testTitle = TextView(this)
        testTitle.text = "Test Your Keyboard"
        testTitle.textSize = 20f
        testTitle.setTextColor(Color.rgb(20, 80, 160))
        testTitle.gravity = Gravity.CENTER
        testTitle.setPadding(5, 25, 5, 10)

        main.addView(testTitle)

        val testInput = EditText(this)
        testInput.hint = "Tu mat mat guk shüm ä......."
        testInput.textSize = 18f
        testInput.minHeight = 100
        testInput.gravity = Gravity.TOP
        testInput.setPadding(15, 15, 15, 15)

        main.addView(
            testInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val testButton = Button(this)
        testButton.text = "OPEN KEYBOARD"

        main.addView(testButton)

        enableButton.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
            )
        }

        selectButton.setOnClickListener {
            val imm = getSystemService(
                Context.INPUT_METHOD_SERVICE
            ) as InputMethodManager

            imm.showInputMethodPicker()
        }

        testButton.setOnClickListener {
            testInput.requestFocus()

            val imm = getSystemService(
                Context.INPUT_METHOD_SERVICE
            ) as InputMethodManager

            imm.showSoftInput(
                testInput,
                InputMethodManager.SHOW_IMPLICIT
            )
        }

        setContentView(main)
    }

    override fun onResume() {
        super.onResume()

        if (::enableStatus.isInitialized) {
            updateKeyboardStatus()
        }
    }

    private fun updateKeyboardStatus() {

        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_INPUT_METHODS
        ) ?: ""

        val selected = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.DEFAULT_INPUT_METHOD
        ) ?: ""

        val isEnabled = enabled.contains(packageName)
        val isSelected = selected.contains(packageName)

        enableStatus.text = if (isEnabled) {
            "✓ Keyboard Enabled"
        } else {
            "✗ Keyboard Not Enabled"
        }

        enableStatus.setTextColor(
            if (isEnabled) Color.rgb(0, 140, 0)
            else Color.RED
        )

        selectStatus.text = if (isSelected) {
            "✓ K'Cho Keyboard Selected"
        } else {
            "✗ K'Cho Keyboard Not Selected"
        }

        selectStatus.setTextColor(
            if (isSelected) Color.rgb(0, 140, 0)
            else Color.RED
        )
    }
}

