package com.daily.kchokeyboard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast

class VoiceTypingActivity : Activity() {

    companion object {
        const val ACTION_VOICE_RESULT =
            "com.daily.kchokeyboard.ACTION_VOICE_RESULT"
        const val ACTION_VOICE_STATE =
            "com.daily.kchokeyboard.ACTION_VOICE_STATE"
        const val ACTION_STOP_VOICE =
            "com.daily.kchokeyboard.ACTION_STOP_VOICE"

        const val EXTRA_RECOGNIZED_TEXT = "recognized_text"
        const val EXTRA_KEYBOARD_MODE = "keyboard_mode"
        const val EXTRA_IS_LISTENING = "is_listening"

        private const val REQUEST_RECORD_AUDIO = 7101
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var finished = false
    private var stopReceiverRegistered = false

    private val stopReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (intent?.action == ACTION_STOP_VOICE) {
                stopListeningAndClose()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // The Activity itself is transparent; speech is handled by SpeechRecognizer.
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showError("ဒီဖုန်းမှာ Speech Recognition မရနိုင်ပါ။")
            return
        }

        val filter = android.content.IntentFilter(ACTION_STOP_VOICE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stopReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(stopReceiver, filter)
        }
        stopReceiverRegistered = true

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startListening()
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO),
                REQUEST_RECORD_AUDIO
            )
        }
    }

    private fun startListening() {
        if (finished || isListening) return

        val keyboardMode = intent.getStringExtra(EXTRA_KEYBOARD_MODE) ?: "KCHO"
        val languageTag = when (keyboardMode) {
            "ENGLISH" -> "en-US"
            "MYANMAR" -> "my-MM"
            // K'Cho-specific recognition may not be provided by Android speech services.
            else -> "my-MM"
        }

        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                        sendVoiceState(true)
                    }

                    override fun onBeginningOfSpeech() {
                        isListening = true
                        sendVoiceState(true)
                    }

                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() {
                        isListening = false
                        sendVoiceState(false)
                    }

                    override fun onError(error: Int) {
                        isListening = false
                        sendVoiceState(false)
                        if (!finished) {
                            val message = when (error) {
                                SpeechRecognizer.ERROR_NO_MATCH,
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                    "အသံမကြားရပါ။ ထပ်မံနှိပ်ပြီး ပြောပါ။"
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                    "Microphone permission မရရှိပါ။"
                                else -> "အသံမှတ်တမ်း မအောင်မြင်ပါ။ Internet နဲ့ Speech service ကို စစ်ပါ။"
                            }
                            showError(message)
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        sendVoiceState(false)
                        val text = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()

                        if (text.isNotEmpty()) {
                            sendBroadcast(
                                Intent(ACTION_VOICE_RESULT).apply {
                                    setPackage(packageName)
                                    putExtra(EXTRA_RECOGNIZED_TEXT, text)
                                }
                            )
                        }
                        finish()
                    }

                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })

                val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                }

                recognizer.startListening(recognizerIntent)
            }
        } catch (_: Exception) {
            showError("အသံမှတ်တမ်း စတင်မရပါ။ Google Speech service ကို စစ်ဆေးပါ။")
        }
    }

    private fun sendVoiceState(listening: Boolean) {
        sendBroadcast(
            Intent(ACTION_VOICE_STATE).apply {
                setPackage(packageName)
                putExtra(EXTRA_IS_LISTENING, listening)
            }
        )
    }

    private fun stopListeningAndClose() {
        try {
            speechRecognizer?.cancel()
        } catch (_: Exception) {
        }
        isListening = false
        sendVoiceState(false)
        finish()
    }

    private fun showError(message: String) {
        if (finished) return
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        sendVoiceState(false)
        finish()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_RECORD_AUDIO) {
            if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                startListening()
            } else {
                showError("အသံနဲ့စာရိုက်ရန် Microphone permission လိုအပ်ပါတယ်။")
            }
        }
    }

    override fun onDestroy() {
        finished = true
        if (isListening) sendVoiceState(false)
        if (stopReceiverRegistered) {
            try {
                unregisterReceiver(stopReceiver)
            } catch (_: Exception) {
            }
        }
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        speechRecognizer = null
        super.onDestroy()
    }
}
